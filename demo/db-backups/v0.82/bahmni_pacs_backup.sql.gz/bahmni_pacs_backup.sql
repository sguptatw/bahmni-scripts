--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: bahmni_pacs; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bahmni_pacs WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE bahmni_pacs OWNER TO postgres;

\connect bahmni_pacs

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255)
);


ALTER TABLE public.databasechangelog OWNER TO pacs;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO pacs;

--
-- Name: event_records_offset_marker; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE event_records_offset_marker (
    id integer NOT NULL,
    event_id integer,
    event_count integer,
    category character varying(255)
);


ALTER TABLE public.event_records_offset_marker OWNER TO pacs;

--
-- Name: event_records_offset_marker_id_seq; Type: SEQUENCE; Schema: public; Owner: pacs
--

CREATE SEQUENCE event_records_offset_marker_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_records_offset_marker_id_seq OWNER TO pacs;

--
-- Name: event_records_offset_marker_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pacs
--

ALTER SEQUENCE event_records_offset_marker_id_seq OWNED BY event_records_offset_marker.id;


--
-- Name: failed_event_retry_log; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE failed_event_retry_log (
    id integer NOT NULL,
    feed_uri character varying(255),
    failed_at timestamp without time zone,
    error_message character varying(4000),
    event_id character varying(255),
    event_content character varying(4000),
    error_hash_code integer
);


ALTER TABLE public.failed_event_retry_log OWNER TO pacs;

--
-- Name: failed_event_retry_log_id_seq; Type: SEQUENCE; Schema: public; Owner: pacs
--

CREATE SEQUENCE failed_event_retry_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_event_retry_log_id_seq OWNER TO pacs;

--
-- Name: failed_event_retry_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pacs
--

ALTER SEQUENCE failed_event_retry_log_id_seq OWNED BY failed_event_retry_log.id;


--
-- Name: failed_events; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE failed_events (
    id integer NOT NULL,
    feed_uri character varying(255),
    failed_at timestamp without time zone,
    error_message character varying(4000),
    event_id character varying(255),
    event_content character varying(4000),
    error_hash_code integer,
    title character varying(255),
    retries integer DEFAULT 0 NOT NULL,
    tags character varying(255)
);


ALTER TABLE public.failed_events OWNER TO pacs;

--
-- Name: failed_events_id_seq; Type: SEQUENCE; Schema: public; Owner: pacs
--

CREATE SEQUENCE failed_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_events_id_seq OWNER TO pacs;

--
-- Name: failed_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pacs
--

ALTER SEQUENCE failed_events_id_seq OWNED BY failed_events.id;


--
-- Name: ht_modality; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE ht_modality (
    id integer NOT NULL,
    hib_sess_id character(36)
);


ALTER TABLE public.ht_modality OWNER TO pacs;

--
-- Name: ht_order_details; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE ht_order_details (
    id integer NOT NULL,
    hib_sess_id character(36)
);


ALTER TABLE public.ht_order_details OWNER TO pacs;

--
-- Name: ht_order_type; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE ht_order_type (
    id integer NOT NULL,
    hib_sess_id character(36)
);


ALTER TABLE public.ht_order_type OWNER TO pacs;

--
-- Name: ht_quartz_cron_scheduler; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE ht_quartz_cron_scheduler (
    id integer NOT NULL,
    hib_sess_id character(36)
);


ALTER TABLE public.ht_quartz_cron_scheduler OWNER TO pacs;

--
-- Name: ht_test_order; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE ht_test_order (
    id integer NOT NULL,
    hib_sess_id character(36)
);


ALTER TABLE public.ht_test_order OWNER TO pacs;

--
-- Name: markers; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE markers (
    feed_uri character varying(255) NOT NULL,
    last_read_entry_id character varying(255),
    feed_uri_for_last_read_entry character varying(255)
);


ALTER TABLE public.markers OWNER TO pacs;

--
-- Name: modality; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE modality (
    id integer NOT NULL,
    name character varying(25),
    description character varying(255),
    ip character varying(20) NOT NULL,
    port integer NOT NULL,
    timeout integer NOT NULL
);


ALTER TABLE public.modality OWNER TO pacs;

--
-- Name: modality_id_seq; Type: SEQUENCE; Schema: public; Owner: pacs
--

CREATE SEQUENCE modality_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.modality_id_seq OWNER TO pacs;

--
-- Name: modality_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pacs
--

ALTER SEQUENCE modality_id_seq OWNED BY modality.id;


--
-- Name: order_details; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE order_details (
    id integer NOT NULL,
    test_order_id integer NOT NULL,
    hl7_request character varying(65535) NOT NULL,
    hl7_response character varying(65535) NOT NULL
);


ALTER TABLE public.order_details OWNER TO pacs;

--
-- Name: order_details_id_seq; Type: SEQUENCE; Schema: public; Owner: pacs
--

CREATE SEQUENCE order_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_details_id_seq OWNER TO pacs;

--
-- Name: order_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pacs
--

ALTER SEQUENCE order_details_id_seq OWNED BY order_details.id;


--
-- Name: order_type; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE order_type (
    id integer NOT NULL,
    name character varying(25),
    modality_id integer NOT NULL
);


ALTER TABLE public.order_type OWNER TO pacs;

--
-- Name: order_type_id_seq; Type: SEQUENCE; Schema: public; Owner: pacs
--

CREATE SEQUENCE order_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_type_id_seq OWNER TO pacs;

--
-- Name: order_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pacs
--

ALTER SEQUENCE order_type_id_seq OWNED BY order_type.id;


--
-- Name: test_order; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE test_order (
    id integer NOT NULL,
    order_type_id integer NOT NULL,
    order_uuid character varying(255) NOT NULL,
    test_name character varying(255) NOT NULL,
    test_uuid character varying(255) NOT NULL,
    result character varying(255),
    creator character varying(255),
    date_created timestamp without time zone,
    modifier character varying(255),
    date_modified timestamp without time zone,
    order_number character varying(16),
    comment character varying(255)
);


ALTER TABLE public.test_order OWNER TO pacs;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: pacs
--

CREATE SEQUENCE orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO pacs;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pacs
--

ALTER SEQUENCE orders_id_seq OWNED BY test_order.id;


--
-- Name: quartz_cron_scheduler; Type: TABLE; Schema: public; Owner: pacs; Tablespace: 
--

CREATE TABLE quartz_cron_scheduler (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    enabled boolean DEFAULT true,
    cron_statement character varying(20) NOT NULL,
    start_delay integer
);


ALTER TABLE public.quartz_cron_scheduler OWNER TO pacs;

--
-- Name: quartz_cron_scheduler_id_seq; Type: SEQUENCE; Schema: public; Owner: pacs
--

CREATE SEQUENCE quartz_cron_scheduler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quartz_cron_scheduler_id_seq OWNER TO pacs;

--
-- Name: quartz_cron_scheduler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pacs
--

ALTER SEQUENCE quartz_cron_scheduler_id_seq OWNED BY quartz_cron_scheduler.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pacs
--

ALTER TABLE ONLY event_records_offset_marker ALTER COLUMN id SET DEFAULT nextval('event_records_offset_marker_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pacs
--

ALTER TABLE ONLY failed_event_retry_log ALTER COLUMN id SET DEFAULT nextval('failed_event_retry_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pacs
--

ALTER TABLE ONLY failed_events ALTER COLUMN id SET DEFAULT nextval('failed_events_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pacs
--

ALTER TABLE ONLY modality ALTER COLUMN id SET DEFAULT nextval('modality_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pacs
--

ALTER TABLE ONLY order_details ALTER COLUMN id SET DEFAULT nextval('order_details_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pacs
--

ALTER TABLE ONLY order_type ALTER COLUMN id SET DEFAULT nextval('order_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pacs
--

ALTER TABLE ONLY quartz_cron_scheduler ALTER COLUMN id SET DEFAULT nextval('quartz_cron_scheduler_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pacs
--

ALTER TABLE ONLY test_order ALTER COLUMN id SET DEFAULT nextval('orders_id_seq'::regclass);


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels) FROM stdin;
100	ict4h	classpath:sql/db_migrations.xml	2017-01-16 06:22:29.18618	1	EXECUTED	7:875caadbed8000a629ff1723f75f3fb7	createTable (x2)		\N	3.4.0	setup	\N
101	ict4h	classpath:sql/db_migrations.xml	2017-01-16 06:22:29.241607	2	EXECUTED	7:edcdfcecc9a1644a7dc71bce929cc060	addColumn		\N	3.4.0	setup	\N
102-1	Jaswanth	classpath:sql/db_migrations.xml	2017-01-16 06:22:29.2659	3	EXECUTED	7:2bd7e3f0ba7a6970c9f4fffa5e9ea2da	addColumn		\N	3.4.0	\N	\N
102-2	Jaswanth	classpath:sql/db_migrations.xml	2017-01-16 06:22:29.325384	4	EXECUTED	7:c6308ab735c513c8c160acbadff9e984	createTable		\N	3.4.0	\N	\N
103	angshu, dubey	classpath:sql/db_migrations.xml	2017-01-16 06:22:29.336598	5	EXECUTED	7:76b8f7c317fadb65966cb1ad47a0318d	addColumn	Creating column tags for failed_events table. This is same as atom spec feed.entry.categories.	\N	3.4.0	setup	\N
103	ict4h	liquibase.xml	2017-01-16 06:22:29.349431	6	MARK_RAN	7:df74fcfe2ec61954d84671f8af8158e1	addColumn		\N	3.4.0	\N	\N
104	ict4h	liquibase.xml	2017-01-16 06:22:29.385365	7	EXECUTED	7:93cb05ccc7c9299ce3fee2c353d6a8fe	createTable		\N	3.4.0	\N	\N
105	ict4h	liquibase.xml	2017-01-16 06:22:29.388486	8	MARK_RAN	7:edcdfcecc9a1644a7dc71bce929cc060	addColumn		\N	3.4.0	\N	\N
PACS-201506250509	Sandeep, Hemanth	liquibase.xml	2017-01-16 06:22:29.41008	9	EXECUTED	7:484721c841790ba53e8959c7a6b6eff8	createTable	Creating quartz cron scheduler Table	\N	3.4.0	\N	\N
PACS-201506250516	Sandeep, Hemanth	liquibase.xml	2017-01-16 06:22:29.428401	10	EXECUTED	7:e526a47b2c90e819477423f332e7f305	createTable	Creating Modality Table	\N	3.4.0	\N	\N
PACS-201506260519	Sandeep, Hemanth	liquibase.xml	2017-01-16 06:22:29.447376	11	EXECUTED	7:2c48ba3cd10d7c82988e262b786b2cd4	createTable, addForeignKeyConstraint	Creating Order Type table	\N	3.4.0	\N	\N
PACS-201506260525	Sandeep, Hemanth	liquibase.xml	2017-01-16 06:22:29.468155	12	EXECUTED	7:1cd6c9de8baae2e978ffa0239094f8f2	createTable, addForeignKeyConstraint	Creating Orders table	\N	3.4.0	\N	\N
PACS-201507020914	Hemanth	liquibase.xml	2017-01-16 06:22:29.484764	13	EXECUTED	7:b06f14de9b74515ea6c988daa32a001c	sql	Adding schedulers for openmrs encounter	\N	3.4.0	\N	\N
PACS-201507061238	Sudhakar, Abishek	liquibase.xml	2017-01-16 06:22:29.491013	14	EXECUTED	7:7589f6f99c9d25377b4520740d3e80a4	renameTable		\N	3.4.0	\N	\N
PACS-201507091128	Sudhakar, Vikash	liquibase.xml	2017-01-16 06:22:29.501676	15	EXECUTED	7:4b0fc355460e011e94c64a8cb09ceb2a	renameTable		\N	3.4.0	\N	\N
PACS-201507151233	Preethi, Sandeep	liquibase.xml	2017-01-16 06:22:29.519871	16	EXECUTED	7:66a85a861b13721f7966b9d6376cdacb	addColumn		\N	3.4.0	\N	\N
PACS-201507220554	JP, Hemanth	liquibase.xml	2017-01-16 06:22:29.53861	17	EXECUTED	7:893a7cc7faa098f47c77d231e6517419	createTable, addForeignKeyConstraint	Creating order details table	\N	3.4.0	\N	\N
PACS-201507292000	Hemanth	liquibase.xml	2017-01-16 06:22:29.543404	18	EXECUTED	7:fd0d376c40cc918d5a839a4f431560a3	addColumn	Adding comment column to order table.	\N	3.4.0	\N	\N
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
\.


--
-- Data for Name: event_records_offset_marker; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY event_records_offset_marker (id, event_id, event_count, category) FROM stdin;
\.


--
-- Name: event_records_offset_marker_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pacs
--

SELECT pg_catalog.setval('event_records_offset_marker_id_seq', 1, false);


--
-- Data for Name: failed_event_retry_log; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY failed_event_retry_log (id, feed_uri, failed_at, error_message, event_id, event_content, error_hash_code) FROM stdin;
3	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:52:00.13	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484563910124298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:f52ec1f0-21b4-4bca-bbb6-206b97bcef56	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	2058203312
4	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:52:10.22	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484563920214298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:a094bf04-0a92-4492-a18d-93500260f9db	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-902765165
5	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:52:20.301	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484563930294298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:1dfe70b3-9dbd-4956-b1d4-685b86529d9b	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	499957580
8	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:53:00.373	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484563970364298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:f52ec1f0-21b4-4bca-bbb6-206b97bcef56	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-1685687628
9	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:53:10.451	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484563980445298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:a094bf04-0a92-4492-a18d-93500260f9db	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-991021575
10	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:53:20.531	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484563990519298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:1dfe70b3-9dbd-4956-b1d4-685b86529d9b	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	1683914274
13	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:54:00.533	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564030525298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:f52ec1f0-21b4-4bca-bbb6-206b97bcef56	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	674431905
14	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:54:10.617	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564040611298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:a094bf04-0a92-4492-a18d-93500260f9db	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	1064192896
15	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:54:20.707	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564050699298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:1dfe70b3-9dbd-4956-b1d4-685b86529d9b	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	60424001
18	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:55:00.728	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564090723298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:f52ec1f0-21b4-4bca-bbb6-206b97bcef56	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-600695897
19	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:55:10.81	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564100802298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:a094bf04-0a92-4492-a18d-93500260f9db	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	124736063
20	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:55:20.877	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564110872298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:1dfe70b3-9dbd-4956-b1d4-685b86529d9b	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-421675239
23	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:56:00.867	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564150859298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:f52ec1f0-21b4-4bca-bbb6-206b97bcef56	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-373125338
24	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:56:10.945	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564160939298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:a094bf04-0a92-4492-a18d-93500260f9db	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-988260566
25	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:56:21.029	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564171023298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:1dfe70b3-9dbd-4956-b1d4-685b86529d9b	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-1347189860
28	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:57:01.028	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564211023298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:f52ec1f0-21b4-4bca-bbb6-206b97bcef56	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	376354933
29	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:57:11.099	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564221093298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:a094bf04-0a92-4492-a18d-93500260f9db	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-170056369
30	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:57:21.19	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564231186298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:1dfe70b3-9dbd-4956-b1d4-685b86529d9b	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	798378997
33	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:58:01.209	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564271201298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:f52ec1f0-21b4-4bca-bbb6-206b97bcef56	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-502073667
34	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:58:11.292	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564281286298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:a094bf04-0a92-4492-a18d-93500260f9db	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-1140279109
35	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:58:21.363	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484564291356298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:1dfe70b3-9dbd-4956-b1d4-685b86529d9b	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	590418912
38	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:58:52.396	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: org.bahmni.module.pacsintegration.exception.HL7MessageException: Unable to Cancel the Order. Previous order is not foundORD-297\n\tat org.bahmni.module.pacsintegration.services.HL7Service.cancelOrderMessage(HL7Service.java:78)\n\tat org.bahmni.module.pacsintegration.services.HL7Service.createMessage(HL7Service.java:43)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:56)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:f52ec1f0-21b4-4bca-bbb6-206b97bcef56	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	1941544011
39	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:58:53.073	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: org.bahmni.module.pacsintegration.exception.HL7MessageException: Unable to Cancel the Order. Previous order is not foundORD-297\n\tat org.bahmni.module.pacsintegration.services.HL7Service.cancelOrderMessage(HL7Service.java:78)\n\tat org.bahmni.module.pacsintegration.services.HL7Service.createMessage(HL7Service.java:43)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:56)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:a094bf04-0a92-4492-a18d-93500260f9db	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	1941544011
40	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:58:53.834	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: org.bahmni.module.pacsintegration.exception.HL7MessageException: Unable to Cancel the Order. Previous order is not foundORD-297\n\tat org.bahmni.module.pacsintegration.services.HL7Service.cancelOrderMessage(HL7Service.java:78)\n\tat org.bahmni.module.pacsintegration.services.HL7Service.createMessage(HL7Service.java:43)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:56)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:1dfe70b3-9dbd-4956-b1d4-685b86529d9b	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	1941544011
41	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:59:05.724	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: org.bahmni.module.pacsintegration.exception.HL7MessageException: Unable to Cancel the Order. Previous order is not foundORD-297\n\tat org.bahmni.module.pacsintegration.services.HL7Service.cancelOrderMessage(HL7Service.java:78)\n\tat org.bahmni.module.pacsintegration.services.HL7Service.createMessage(HL7Service.java:43)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:56)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:f52ec1f0-21b4-4bca-bbb6-206b97bcef56	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	1941544011
42	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:59:06.449	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: org.bahmni.module.pacsintegration.exception.HL7MessageException: Unable to Cancel the Order. Previous order is not foundORD-297\n\tat org.bahmni.module.pacsintegration.services.HL7Service.cancelOrderMessage(HL7Service.java:78)\n\tat org.bahmni.module.pacsintegration.services.HL7Service.createMessage(HL7Service.java:43)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:56)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:a094bf04-0a92-4492-a18d-93500260f9db	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	1941544011
43	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:59:07.106	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: org.bahmni.module.pacsintegration.exception.HL7MessageException: Unable to Cancel the Order. Previous order is not foundORD-297\n\tat org.bahmni.module.pacsintegration.services.HL7Service.cancelOrderMessage(HL7Service.java:78)\n\tat org.bahmni.module.pacsintegration.services.HL7Service.createMessage(HL7Service.java:43)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:56)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:1dfe70b3-9dbd-4956-b1d4-685b86529d9b	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	1941544011
44	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:59:17.539	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: org.bahmni.module.pacsintegration.exception.HL7MessageException: Unable to Cancel the Order. Previous order is not foundORD-297\n\tat org.bahmni.module.pacsintegration.services.HL7Service.cancelOrderMessage(HL7Service.java:78)\n\tat org.bahmni.module.pacsintegration.services.HL7Service.createMessage(HL7Service.java:43)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:56)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:f52ec1f0-21b4-4bca-bbb6-206b97bcef56	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	1941544011
45	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:59:18.167	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: org.bahmni.module.pacsintegration.exception.HL7MessageException: Unable to Cancel the Order. Previous order is not foundORD-297\n\tat org.bahmni.module.pacsintegration.services.HL7Service.cancelOrderMessage(HL7Service.java:78)\n\tat org.bahmni.module.pacsintegration.services.HL7Service.createMessage(HL7Service.java:43)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:56)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:a094bf04-0a92-4492-a18d-93500260f9db	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	1941544011
46	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:59:18.791	Failed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$FailedEventProcessor.doInTransaction(AtomFeedClient.java:251)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processFailedEvents(AtomFeedClient.java:98)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFailedFeedJob.process(EncounterFailedFeedJob.java:39)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: org.bahmni.module.pacsintegration.exception.HL7MessageException: Unable to Cancel the Order. Previous order is not foundORD-297\n\tat org.bahmni.module.pacsintegration.services.HL7Service.cancelOrderMessage(HL7Service.java:78)\n\tat org.bahmni.module.pacsintegration.services.HL7Service.createMessage(HL7Service.java:43)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:56)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:1dfe70b3-9dbd-4956-b1d4-685b86529d9b	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	1941544011
\.


--
-- Name: failed_event_retry_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pacs
--

SELECT pg_catalog.setval('failed_event_retry_log_id_seq', 46, true);


--
-- Data for Name: failed_events; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY failed_events (id, feed_uri, failed_at, error_message, event_id, event_content, error_hash_code, title, retries, tags) FROM stdin;
4	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:51:19.795	Failed processing event in feed [http://localhost:8050/openmrs/ws/atomfeed/encounter/4] \nFailed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$EventProcessor.doInTransaction(AtomFeedClient.java:168)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processEvents(AtomFeedClient.java:68)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFeedJob.process(EncounterFeedJob.java:38)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484563869789298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:a094bf04-0a92-4492-a18d-93500260f9db	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-1563640007	Encounter	10	Encounter
5	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:51:29.87	Failed processing event in feed [http://localhost:8050/openmrs/ws/atomfeed/encounter/4] \nFailed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$EventProcessor.doInTransaction(AtomFeedClient.java:168)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processEvents(AtomFeedClient.java:68)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFeedJob.process(EncounterFeedJob.java:38)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484563879863298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:1dfe70b3-9dbd-4956-b1d4-685b86529d9b	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-1447648329	Encounter	10	Encounter
3	http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	2017-01-16 18:51:09.675	Failed processing event in feed [http://localhost:8050/openmrs/ws/atomfeed/encounter/4] \nFailed send order to modalityjava.lang.RuntimeException: Failed send order to modality\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:42)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient$EventProcessor.doInTransaction(AtomFeedClient.java:168)\n\tat org.ict4h.atomfeed.transaction.AFTransactionWorkWithoutResult.execute(AFTransactionWorkWithoutResult.java:6)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager$1.doInTransaction(AtomFeedHibernateTransactionManager.java:54)\n\tat org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:133)\n\tat org.bahmni.module.pacsintegration.atomfeed.client.AtomFeedHibernateTransactionManager.executeWithTransaction(AtomFeedHibernateTransactionManager.java:51)\n\tat org.ict4h.atomfeed.client.service.AtomFeedClient.processEvents(AtomFeedClient.java:68)\n\tat org.bahmni.module.pacsintegration.atomfeed.jobs.EncounterFeedJob.process(EncounterFeedJob.java:38)\n\tat org.bahmni.module.pacsintegration.atomfeed.ScheduledTasks$1.run(ScheduledTasks.java:79)\n\tat org.springframework.scheduling.support.DelegatingErrorHandlingRunnable.run(DelegatingErrorHandlingRunnable.java:54)\n\tat org.springframework.scheduling.concurrent.ReschedulingRunnable.run(ReschedulingRunnable.java:81)\n\tat java.util.concurrent.Executors$RunnableAdapter.call(Unknown Source)\n\tat java.util.concurrent.FutureTask.run(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$201(Unknown Source)\n\tat java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n\tat java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n\tat java.lang.Thread.run(Unknown Source)\nCaused by: ca.uhn.hl7v2.HL7Exception: Timeout waiting for response to message with control ID 1484563859669298\n\tat ca.uhn.hl7v2.app.ActiveInitiator.sendAndReceive(ActiveInitiator.java:153)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.post(ModalityService.java:54)\n\tat org.bahmni.module.pacsintegration.services.ModalityService.sendMessage(ModalityService.java:30)\n\tat org.bahmni.module.pacsintegration.services.PacsIntegrationService.processEncounter(PacsIntegrationService.java:57)\n\tat org.bahmni.module.pacsintegration.atomfeed.worker.EncounterFeedWorker.process(EncounterFeedWorker.java:37)\n\t... 17 more\n	tag:atomfeed.ict4h.org:f52ec1f0-21b4-4bca-bbb6-206b97bcef56	/openmrs/ws/rest/v1/bahmnicore/bahmniencounter/1d7a9c48-a87f-46bd-904e-e7b89c1a9194?includeAll=true	-155106375	Encounter	10	Encounter
\.


--
-- Name: failed_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pacs
--

SELECT pg_catalog.setval('failed_events_id_seq', 5, true);


--
-- Data for Name: ht_modality; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY ht_modality (id, hib_sess_id) FROM stdin;
\.


--
-- Data for Name: ht_order_details; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY ht_order_details (id, hib_sess_id) FROM stdin;
\.


--
-- Data for Name: ht_order_type; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY ht_order_type (id, hib_sess_id) FROM stdin;
\.


--
-- Data for Name: ht_quartz_cron_scheduler; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY ht_quartz_cron_scheduler (id, hib_sess_id) FROM stdin;
\.


--
-- Data for Name: ht_test_order; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY ht_test_order (id, hib_sess_id) FROM stdin;
\.


--
-- Data for Name: markers; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY markers (feed_uri, last_read_entry_id, feed_uri_for_last_read_entry) FROM stdin;
http://localhost:8050/openmrs/ws/atomfeed/encounter/recent	tag:atomfeed.ict4h.org:1dfe70b3-9dbd-4956-b1d4-685b86529d9b	http://localhost:8050/openmrs/ws/atomfeed/encounter/4
\.


--
-- Data for Name: modality; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY modality (id, name, description, ip, port, timeout) FROM stdin;
1	DCM4CHEE	DCM4CHEE PACS	localhost	11112	3000
2	PACS	PACS INTEGRATION	localhost	8087	3000
\.


--
-- Name: modality_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pacs
--

SELECT pg_catalog.setval('modality_id_seq', 1, false);


--
-- Data for Name: order_details; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY order_details (id, test_order_id, hl7_request, hl7_response) FROM stdin;
4	4	MSH|^~\\&||BahmniEMR^BahmniEMR|||2017011618||ORM^O01|1484564343659286|P|2.5\rPID|||GAN200017||^GAN200017||19590309000000+0730|M\rORC|NW|ORD-286|ORD-286||||^^^^^ROUTINE|||^^BahmniEMR||c1c26908-3f10-11e4-adec-0800271c1b75^^Super Man\rOBR||||1234^abdomen ap|||||||||||||||||||||||||||||||||||^Chest, 1 view (X-ray)||||^TestPatientWith,DeletableDiagnosis\r	MSH|^~\\&||BahmniEMR^BahmniEMR|||20170116105904||ORR^O02||P|2.5\rMSA|AA|1484564343659286\r
5	5	MSH|^~\\&||BahmniEMR^BahmniEMR|||2017011618||ORM^O01|1484564344293288|P|2.5\rPID|||GAN200019||^GAN200019||20020331000000+0800|M\rORC|NW|ORD-288|ORD-288||||^^^^^ROUTINE|||^^BahmniEMR||c1c26908-3f10-11e4-adec-0800271c1b75^^Super Man\rOBR||||1234^abdomen ap|||||||||||||||||||||||||||||||||||^Chest oblique - Bilateral (X-ray)||||^Test,Radiology\r	MSH|^~\\&||BahmniEMR^BahmniEMR|||20170116105905||ORR^O02||P|2.5\rMSA|AA|1484564344293288\r
\.


--
-- Name: order_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pacs
--

SELECT pg_catalog.setval('order_details_id_seq', 11, true);


--
-- Data for Name: order_type; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY order_type (id, name, modality_id) FROM stdin;
1	Radiology Order	2
\.


--
-- Name: order_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pacs
--

SELECT pg_catalog.setval('order_type_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pacs
--

SELECT pg_catalog.setval('orders_id_seq', 11, true);


--
-- Data for Name: quartz_cron_scheduler; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY quartz_cron_scheduler (id, name, enabled, cron_statement, start_delay) FROM stdin;
1	openMRSEncounterFeedJob	t	0/15 * * * * ?	0
2	openMRSEncounterFailedFeedJob	t	0/15 * * * * ?	0
\.


--
-- Name: quartz_cron_scheduler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pacs
--

SELECT pg_catalog.setval('quartz_cron_scheduler_id_seq', 2, true);


--
-- Data for Name: test_order; Type: TABLE DATA; Schema: public; Owner: pacs
--

COPY test_order (id, order_type_id, order_uuid, test_name, test_uuid, result, creator, date_created, modifier, date_modified, order_number, comment) FROM stdin;
4	1	cb9e20dc-0b65-40dd-8cf7-053ed8168d35	Chest, 1 view (X-ray)	c39ed470-3f10-11e4-adec-0800271c1b75	\N	Super Man	2017-01-16 18:59:04.24	\N	\N	ORD-286	\N
5	1	64be8ae0-5622-4913-98e0-d5f2b329155d	Chest oblique - Bilateral (X-ray)	c3e8841a-3f10-11e4-adec-0800271c1b75	\N	Super Man	2017-01-16 18:59:05.049	\N	\N	ORD-288	\N
\.


--
-- Name: pk_databasechangeloglock; Type: CONSTRAINT; Schema: public; Owner: pacs; Tablespace: 
--

ALTER TABLE ONLY databasechangeloglock
    ADD CONSTRAINT pk_databasechangeloglock PRIMARY KEY (id);


--
-- Name: pk_event_records_offset_marker; Type: CONSTRAINT; Schema: public; Owner: pacs; Tablespace: 
--

ALTER TABLE ONLY event_records_offset_marker
    ADD CONSTRAINT pk_event_records_offset_marker PRIMARY KEY (id);


--
-- Name: pk_failed_event_retry_log; Type: CONSTRAINT; Schema: public; Owner: pacs; Tablespace: 
--

ALTER TABLE ONLY failed_event_retry_log
    ADD CONSTRAINT pk_failed_event_retry_log PRIMARY KEY (id);


--
-- Name: pk_failed_events; Type: CONSTRAINT; Schema: public; Owner: pacs; Tablespace: 
--

ALTER TABLE ONLY failed_events
    ADD CONSTRAINT pk_failed_events PRIMARY KEY (id);


--
-- Name: pk_markers; Type: CONSTRAINT; Schema: public; Owner: pacs; Tablespace: 
--

ALTER TABLE ONLY markers
    ADD CONSTRAINT pk_markers PRIMARY KEY (feed_uri);


--
-- Name: pk_modality; Type: CONSTRAINT; Schema: public; Owner: pacs; Tablespace: 
--

ALTER TABLE ONLY modality
    ADD CONSTRAINT pk_modality PRIMARY KEY (id);


--
-- Name: pk_order_details; Type: CONSTRAINT; Schema: public; Owner: pacs; Tablespace: 
--

ALTER TABLE ONLY order_details
    ADD CONSTRAINT pk_order_details PRIMARY KEY (id);


--
-- Name: pk_order_type; Type: CONSTRAINT; Schema: public; Owner: pacs; Tablespace: 
--

ALTER TABLE ONLY order_type
    ADD CONSTRAINT pk_order_type PRIMARY KEY (id);


--
-- Name: pk_orders; Type: CONSTRAINT; Schema: public; Owner: pacs; Tablespace: 
--

ALTER TABLE ONLY test_order
    ADD CONSTRAINT pk_orders PRIMARY KEY (id);


--
-- Name: pk_quartz_cron_scheduler; Type: CONSTRAINT; Schema: public; Owner: pacs; Tablespace: 
--

ALTER TABLE ONLY quartz_cron_scheduler
    ADD CONSTRAINT pk_quartz_cron_scheduler PRIMARY KEY (id);


--
-- Name: fk_od_test_order_id; Type: FK CONSTRAINT; Schema: public; Owner: pacs
--

ALTER TABLE ONLY order_details
    ADD CONSTRAINT fk_od_test_order_id FOREIGN KEY (test_order_id) REFERENCES test_order(id);


--
-- Name: fk_os_order_type; Type: FK CONSTRAINT; Schema: public; Owner: pacs
--

ALTER TABLE ONLY test_order
    ADD CONSTRAINT fk_os_order_type FOREIGN KEY (order_type_id) REFERENCES order_type(id);


--
-- Name: fk_ot_modality; Type: FK CONSTRAINT; Schema: public; Owner: pacs
--

ALTER TABLE ONLY order_type
    ADD CONSTRAINT fk_ot_modality FOREIGN KEY (modality_id) REFERENCES modality(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: failed_event_retry_log; Type: ACL; Schema: public; Owner: pacs
--

REVOKE ALL ON TABLE failed_event_retry_log FROM PUBLIC;
REVOKE ALL ON TABLE failed_event_retry_log FROM pacs;
GRANT ALL ON TABLE failed_event_retry_log TO pacs;
GRANT SELECT,UPDATE ON TABLE failed_event_retry_log TO "atomfeed-console";


--
-- Name: failed_events; Type: ACL; Schema: public; Owner: pacs
--

REVOKE ALL ON TABLE failed_events FROM PUBLIC;
REVOKE ALL ON TABLE failed_events FROM pacs;
GRANT ALL ON TABLE failed_events TO pacs;
GRANT SELECT,UPDATE ON TABLE failed_events TO "atomfeed-console";


--
-- Name: markers; Type: ACL; Schema: public; Owner: pacs
--

REVOKE ALL ON TABLE markers FROM PUBLIC;
REVOKE ALL ON TABLE markers FROM pacs;
GRANT ALL ON TABLE markers TO pacs;
GRANT SELECT,UPDATE ON TABLE markers TO "atomfeed-console";


--
-- PostgreSQL database dump complete
--

